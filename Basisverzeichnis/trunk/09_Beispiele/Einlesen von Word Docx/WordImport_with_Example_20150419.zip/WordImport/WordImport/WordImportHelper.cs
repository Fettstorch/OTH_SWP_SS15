﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Wordprocessing;
using Table = DocumentFormat.OpenXml.Wordprocessing.Table;

namespace WordImport
{
    public static class WordImportHelper
    {

        private enum ImportStep {Name, Id, Priority, Description, PreCondition, AfterCondition, NormalProcess,PossibleProcesses, SpecialRequirements,OpenPoints};



        private static Dictionary<string, ImportStep> StepNames = new Dictionary<string, ImportStep>()
                                                                   {
                                                                       {"Kennung",ImportStep.Id},
                                                                       {"Priorität",ImportStep.Priority},
                                                                       {"Kurzbeschreibung:",ImportStep.Description},
                                                                       {"Vorbedingung(en):",ImportStep.PreCondition},
                                                                       {"Nachbedingung(en):",ImportStep.AfterCondition},
                                                                       {"Normaler Ablauf:",ImportStep.NormalProcess},
                                                                       {"Ablauf-Varianten:",ImportStep.PossibleProcesses},
                                                                       {"Spezielle Anforderungen:",ImportStep.SpecialRequirements},
                                                                       {"Zu klärende Punkte:",ImportStep.OpenPoints},
                                                                   };



        public static List<Graph> ImportDocument(string filename)
        {
            List<Graph> ergGraphList = new List<Graph>();

            if (!File.Exists(filename))
                return ergGraphList;

            WordprocessingDocument doc;
            try
            {
                 doc = WordprocessingDocument.Open(filename, false);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return ergGraphList;
            }
        
            MainDocumentPart mainDocument = doc.MainDocumentPart;
            Document document = mainDocument.Document;

            

            //get all tables of document
            var tables = document.Descendants<Table>();
            foreach (var table in tables)
            {
                var rows = table.Descendants<TableRow>();

                //get all rows of table
                IList<TableRow> sourceRows = rows as TableRow[] ?? rows.ToArray();
                foreach (var row in sourceRows)
                {
                    //get all cells of tablerow
                    var cells = row.Descendants<TableCell>();
                    var tcVar = cells.ToList();
                    foreach (var tx in tcVar)
                    {
                        if (StepNames.ContainsKey(tx.InnerText) && StepNames[tx.InnerText] == ImportStep.NormalProcess)
                        {
                            ergGraphList.Add(ReadInUseCases(sourceRows));
                            break;
                        }
                    }
                }
            }
            return ergGraphList; 
        }


        private static Graph ReadInUseCases(IList<TableRow> sourceRows)
        {
            string variantIndex = "",variantName = "", previousVariantIndex = "";
            Regex rgx = new Regex("[^0-9]");
            Knoten oldKnoten = null;
            Graph ergGraph = new Graph();

            
            if (sourceRows.Count < 1)
                return ergGraph;

            IList<TableCell> titleUseCase = sourceRows[0].Descendants<TableCell>().ToList();
            ergGraph.Name = titleUseCase[0].InnerText;
            ImportStep currentImportStep = ImportStep.Name;

            for (int i = 1; i < sourceRows.Count; i++)
            {
                List<TableCell> cells = sourceRows[i].Descendants<TableCell>().ToList();

                if (StepNames.ContainsKey(cells[0].InnerText))
                {
                    currentImportStep = StepNames[cells[0].InnerText];
                    if (cells.Count==1)
                        continue;
                }



                switch (currentImportStep)
                {
                    case ImportStep.Id:
                        if (cells.Count > 1)
                            ergGraph.Id = cells[1].InnerText;
                        break;
                    case ImportStep.Priority:
                        if (cells.Count > 1)
                            ergGraph.Priority = cells[1].InnerText;
                        break;
                    case ImportStep.Description:
                        ergGraph.Description = cells[0].InnerText;
                        break;
                    case ImportStep.PreCondition:
                        ergGraph.PreCondition = cells[0].InnerText;
                        break;
                    case ImportStep.AfterCondition:
                        ergGraph.AfterCondition = cells[0].InnerText;
                        break;
                    case ImportStep.NormalProcess:
                        List<Paragraph> paragraphsList = cells[1].Descendants<Paragraph>().ToList();
                        string lastCondition = paragraphsList[paragraphsList.Count - 1].InnerText;
                        string lastConditionId = "";
                        for(int j = 0; j< paragraphsList.Count - 1;j++)
                        {
                            Knoten newKnoten = new Knoten((j+1).ToString(), paragraphsList[j].InnerText);
                            ergGraph.KnotenList.Add(newKnoten);
                            if (oldKnoten != null)
                                ergGraph.KantenList.Add(new Kanten(oldKnoten, newKnoten));
                            oldKnoten = newKnoten;
                        }
                        break;
                    case ImportStep.PossibleProcesses:
                        if (!cells[0].InnerText.Equals(""))
                        {
                            variantIndex = cells[0].InnerText;
                            previousVariantIndex = "";
                            if (cells.Count > 1)
                                variantName = cells[1].InnerText;
                            continue;
                        }
                        List<Paragraph> paragraphsList2 = cells[1].Descendants<Paragraph>().ToList();
                        if (paragraphsList2.Count > 0)
                        {
                            string lastCondition2 = paragraphsList2[paragraphsList2.Count - 1].InnerText;
                            string lastConditionId2 = "";
                            for(int j = 0; j< paragraphsList2.Count - 1;j++)
                            {
                                Knoten newKnoten = new Knoten(variantIndex + (j+1), paragraphsList2[j].InnerText);
                                ergGraph.KnotenList.Add(newKnoten);
                                string IndexNumber = rgx.Replace(variantIndex, "");
                                
                                if (previousVariantIndex.Equals(""))
                                    previousVariantIndex = IndexNumber;
                                Knoten  searchKnoten = ergGraph.KnotenList.Find(knoten => knoten.Index.Equals(previousVariantIndex));
                                if(searchKnoten != null)
                                    ergGraph.KantenList.Add(new Kanten(searchKnoten,newKnoten));
                                previousVariantIndex = variantIndex + (j+1);
                            }

                            if (lastCondition2.StartsWith("Rückkehr nach:"))
                            {
                                lastConditionId2 = lastCondition2.Replace("Rückkehr nach:", "").Replace(" ", "");
                                if (ergGraph.KnotenList.Exists(knoten => knoten.Index == lastConditionId2))
                                {
                                    Knoten searchKnoten = ergGraph.KnotenList.Find(knoten => knoten.Index == lastConditionId2);
                                    Knoten lastKnoten = ergGraph.KnotenList.Find(knoten => knoten.Index == previousVariantIndex);
                                    if (searchKnoten != null && lastKnoten != null)
                                        ergGraph.KantenList.Add(new Kanten(lastKnoten, searchKnoten));
                                }
                            }
                        }
                        break;
                    case ImportStep.SpecialRequirements:
                        ergGraph.SpecialRequirements = cells[0].InnerText;
                        break;
                    case ImportStep.OpenPoints:
                        ergGraph.OpenPoints = cells[0].InnerText;
                        break;
                }
            }
            
            return ergGraph;
        }
        


        public class Graph
        {
            public List<Knoten> KnotenList = new List<Knoten>();
            public List<Kanten> KantenList = new List<Kanten>();
            public Dictionary<string,string> Properties = new Dictionary<string, string>();
            public string Name, Id, Priority, Description, PreCondition, AfterCondition, SpecialRequirements, OpenPoints;
        }

        public class Knoten
        {
            public  string Index;
            public string Description; 
            public Knoten(string index ,string description)
            {
                Index = index;
                Description = description;
            }
        }

        public class Kanten
        {
            public Knoten RefKnoten1;
            public Knoten RefKnoten2;
            public string VariantName;

            public Kanten(Knoten refKnoten1, Knoten refKnoten2, string variantName = "")
            {
                RefKnoten1 = refKnoten1;
                RefKnoten2 = refKnoten2;
                VariantName = variantName;
            }
        }
    }
}
