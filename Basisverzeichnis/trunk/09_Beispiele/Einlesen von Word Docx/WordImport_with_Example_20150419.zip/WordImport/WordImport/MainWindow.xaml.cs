﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace WordImport
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ///http://www.microsoft.com/en-us/download/confirmation.aspx?id=5124
            /// 
        }

        private void ImportButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlgOpen = new OpenFileDialog();
            if (dlgOpen.ShowDialog() == true)
            {
                lstKanten.Items.Clear();
                lstKnoten.Items.Clear();
                lstGraphProp.Items.Clear();
                List<WordImportHelper.Graph> erGraph = WordImportHelper.ImportDocument(dlgOpen.FileName);
                if(erGraph == null)
                    return;

                for (int j = 0; j < erGraph.Count; j++)
                {

                    lstKanten.Items.Add("Kanten von UseCase " + erGraph[j].Id + " :");
                    lstKnoten.Items.Add("Knoten von UseCase " + erGraph[j].Id + " :");
                    lstGraphProp.Items.Add("Attribute des UseCases(Graph) " + erGraph[j].Id + " :");
                    
                    for (int i = 0; i < erGraph[j].KantenList.Count; i++)
                    {
                        string text = "Kante beinhaltet Knoten Index ";
                        lstKanten.Items.Add(text + erGraph[j].KantenList[i].RefKnoten1.Index + " & " +
                                            erGraph[j].KantenList[i].RefKnoten2.Index);
                    }
                    for (int i = 0; i < erGraph[j].KnotenList.Count; i++)
                    {
                        string text = "Knoten Index: ";
                        lstKnoten.Items.Add(text + erGraph[j].KnotenList[i].Index + " Descr.: " +
                                            erGraph[j].KnotenList[i].Description);
                    }

                    lstGraphProp.Items.Add("Name: " + erGraph[j].Name);
                    lstGraphProp.Items.Add("Kennung: " + erGraph[j].Id);
                    lstGraphProp.Items.Add("Priorität: " + erGraph[j].Priority);
                    lstGraphProp.Items.Add("Kurzbeschreibung: " + erGraph[j].Description);
                    lstGraphProp.Items.Add("Vorbedingung: " + erGraph[j].PreCondition);
                    lstGraphProp.Items.Add("Nachbedingung: " + erGraph[j].AfterCondition);
                    lstGraphProp.Items.Add("Spezielle Anforderungen: " + erGraph[j].SpecialRequirements);
                    lstGraphProp.Items.Add("Zu klärende Punkte: " + erGraph[j].OpenPoints);
                }
               
            }
        
        }
    }
}
